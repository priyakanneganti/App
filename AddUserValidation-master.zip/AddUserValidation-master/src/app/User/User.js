"use strict";
var User = (function () {
    function User(userID, emailId, age) {
        this.userID = userID;
        this.emailId = emailId;
        this.age = age;
    }
    return User;
}());
exports.User = User;
//# sourceMappingURL=User.js.map