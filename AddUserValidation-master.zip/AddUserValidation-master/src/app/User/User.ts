export class User  { 
      userID:string;
      emailId:string;
      age:number;

      constructor(userID:string, emailId:string, age:number){
            this.userID=userID;
            this.emailId=emailId;
            this.age=age;
      }
}
