"use strict";
var MenuItem = (function () {
    function MenuItem(menuName, menuValue) {
        this.menuName = menuName;
        this.menuValue = menuValue;
    }
    return MenuItem;
}());
exports.MenuItem = MenuItem;
//# sourceMappingURL=MenuItem.js.map