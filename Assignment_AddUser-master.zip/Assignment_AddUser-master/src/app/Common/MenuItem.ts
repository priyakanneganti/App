export class MenuItem{
    menuName:string;
    menuValue:string;

    constructor(menuName:string, menuValue:string){
        this.menuName=menuName;
        this.menuValue=menuValue;
    }
}