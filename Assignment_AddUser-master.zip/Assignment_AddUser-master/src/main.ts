import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { MainModule } from './app/app.mainmodule';

platformBrowserDynamic().bootstrapModule(MainModule);
